﻿namespace DoctorAppointmentBooking.Domain.Interfaces;

public class SpecialtyService
{
    
}
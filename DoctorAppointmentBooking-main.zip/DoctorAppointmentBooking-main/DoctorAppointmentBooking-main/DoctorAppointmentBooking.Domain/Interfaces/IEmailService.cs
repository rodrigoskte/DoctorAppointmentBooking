﻿namespace DoctorAppointmentBooking.Domain.Interfaces
{
    public interface IEmailService
    {
    }
}

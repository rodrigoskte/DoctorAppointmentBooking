﻿using DoctorAppointmentBooking.Domain.Interfaces;

namespace DoctorAppointmentBooking.Application.Services
{
    public class EmailService : IEmailService
    {
    }
}

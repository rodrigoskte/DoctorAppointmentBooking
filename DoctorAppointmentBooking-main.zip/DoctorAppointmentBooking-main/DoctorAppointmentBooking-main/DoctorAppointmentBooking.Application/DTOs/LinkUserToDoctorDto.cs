﻿namespace DoctorAppointmentBooking.Application.DTOs;

public class LinkUserToDoctorDto
{
    public string UserId { get; set; }
    public int DoctorId { get; set; }
}
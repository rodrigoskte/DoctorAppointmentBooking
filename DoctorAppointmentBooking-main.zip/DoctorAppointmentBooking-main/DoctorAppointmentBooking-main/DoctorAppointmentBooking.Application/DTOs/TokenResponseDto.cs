﻿namespace DoctorAppointmentBooking.Application.DTOs;

public class TokenResponseDto
{
    public string Token { get; set; }
}
﻿namespace DoctorAppointmentBooking.Application.DTOs;

public class LinkUserToPatientDto
{
    public string UserId { get; set; }
    public int PatientId { get; set; }
}
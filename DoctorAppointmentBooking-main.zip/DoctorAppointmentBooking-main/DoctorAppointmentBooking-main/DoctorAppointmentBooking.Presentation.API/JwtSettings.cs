﻿namespace MedicalAppointment.Presentation.API;

public class JwtSettings
{
    
}
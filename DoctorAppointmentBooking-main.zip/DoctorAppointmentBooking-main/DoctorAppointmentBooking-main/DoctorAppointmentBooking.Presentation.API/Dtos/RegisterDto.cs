﻿namespace MedicalAppointment.Presentation.API.Dtos;

public class RegisterDto
{
    
}